import java.util.Random;
import java.util.Scanner;

public class WordSearch {

    private static final int GRID_SIZE = 10;
    private static char[][] board = new char[GRID_SIZE][GRID_SIZE];
    private static String[] words = {"JAVA", "ARRAY", "SEARCH", "GAME", "PUZZLE"};
    
    public static void main(String[] args) {
        initializeBoard();
        placeWords();
        fillEmptySpaces();
        printBoard();

        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Enter a word to search (or type 'exit' to quit): ");
            String word = scanner.next().toUpperCase();
            if (word.equals("EXIT")) {
                break;
            }
            if (searchWord(word)) {
                System.out.println("Word found!");
            } else {
                System.out.println("Word not found.");
            }
        }
        scanner.close();
    }

    // Initialize the game board with empty spaces
    private static void initializeBoard() {
        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                board[row][col] = '.';
            }
        }
    }

    // Place words randomly on the board
    private static void placeWords() {
        Random rand = new Random();
        for (String word : words) {
            int row, col, dir;
            boolean placed = false;
            while (!placed) {
                row = rand.nextInt(GRID_SIZE);
                col = rand.nextInt(GRID_SIZE);
                dir = rand.nextInt(3); // 0: horizontal, 1: vertical, 2: diagonal
                
                if (canPlaceWord(word, row, col, dir)) {
                    placeWord(word, row, col, dir);
                    placed = true;
                }
            }
        }
    }

    // Check if a word can be placed at the specified location and direction
    private static boolean canPlaceWord(String word, int row, int col, int dir) {
        int wordLen = word.length();
        switch (dir) {
            case 0: // Horizontal
                if (col + wordLen > GRID_SIZE) return false;
                for (int i = 0; i < wordLen; i++) {
                    if (board[row][col + i] != '.') return false;
                }
                break;
            case 1: // Vertical
                if (row + wordLen > GRID_SIZE) return false;
                for (int i = 0; i < wordLen; i++) {
                    if (board[row + i][col] != '.') return false;
                }
                break;
            case 2: // Diagonal
                if (row + wordLen > GRID_SIZE || col + wordLen > GRID_SIZE) return false;
                for (int i = 0; i < wordLen; i++) {
                    if (board[row + i][col + i] != '.') return false;
                }
                break;
        }
        return true;
    }

    // Place a word on the board at the specified location and direction
    private static void placeWord(String word, int row, int col, int dir) {
        int wordLen = word.length();
        switch (dir) {
            case 0: // Horizontal
                for (int i = 0; i < wordLen; i++) {
                    board[row][col + i] = word.charAt(i);
                }
                break;
            case 1: // Vertical
                for (int i = 0; i < wordLen; i++) {
                    board[row + i][col] = word.charAt(i);
                }
                break;
            case 2: // Diagonal
                for (int i = 0; i < wordLen; i++) {
                    board[row + i][col + i] = word.charAt(i);
                }
                break;
        }
    }

    // Fill the empty spaces with random letters
    private static void fillEmptySpaces() {
        Random rand = new Random();
        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                if (board[row][col] == '.') {
                    board[row][col] = (char) (rand.nextInt(26) + 'A');
                }
            }
        }
    }

    // Print the game board
    private static void printBoard() {
        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                System.out.print(board[row][col] + " ");
            }
            System.out.println();
        }
    }

    // Search for a word in the board
    private static boolean searchWord(String word) {
        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                if (board[row][col] == word.charAt(0)) {
                    if (searchInDirection(word, row, col, 0, 1) || // Horizontal
                        searchInDirection(word, row, col, 1, 0) || // Vertical
                        searchInDirection(word, row, col, 1, 1))   // Diagonal
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    // Search for a word in a specific direction
    private static boolean searchInDirection(String word, int row, int col, int rowDir, int colDir) {
        int wordLen = word.length();
        for (int i = 0; i < wordLen; i++) {
            if (row + i * rowDir >= GRID_SIZE || col + i * colDir >= GRID_SIZE || board[row + i * rowDir][col + i * colDir] != word.charAt(i)) {
                return false;
            }
        }
        return true;
    }
}
